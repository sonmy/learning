//
//  FLVTag.m
//  protos
//
//  Created by Min Kim on 10/10/13.
//  Copyright (c) 2013 iFactory Lab Limited. All rights reserved.
//

#import "FLVTag.h"

@implementation FLVTag

- (NSString *)toString {
  return @"";
}

@end
