//
//  AppDelegate.h
//  IFVideoPickerDemo
//
//  Created by Min Kim on 11/5/13.
//  Copyright (c) 2013 iFactory Lab Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
