//
//  main.cpp
//  qmcdecoder
//
//  Created by mysong on 2020/7/6.
//  Copyright © 2020 mys. All rights reserved.
//

#include <iostream>
namespace BBB {void sub_process(std::string dir);}
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    BBB::sub_process("/Users/mysong/log分析/qmc/田馥甄-魔鬼中的天使.qmcflac");
    return 0;
}
